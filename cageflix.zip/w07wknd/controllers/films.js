module.exports = {
  index:  filmsIndex,
  create: filmsCreate,
  show:   filmsShow,
  update: filmsUpdate,
  delete: filmsDelete
};

const Film = require('../models/film');

function filmsIndex(req, res) {
  Film.find((err, films) => {
    if (err) return res.status(500).json({ message: "Something went wrong." });
    return res.status(200).json({films});
  });
}

function filmsCreate(req, res) {
  const film = new Film(req.body.film);
  film.save((err, film) => {
    if (err) return res.status(500).json({ messsage: "Something went wrong." });
    return res.status(201).json({film});
  });
}

function filmsShow(req, res) {
  Film.findById(req.params.id, (err, film) => {
    if (err) return res.status(500).json({ messsage: "Something went wrong." });
    if (!film) return res.status(404).json({ message: "No film found. "});
    return res.status(200).json({film});
  });
}

function filmsUpdate(req, res) {
  Film.findByIdAndUpdate(req.params.id, req.body.film, (err, film) => {
    if (err) return res.status(500).json({ messsage: "Something went wrong." });
    if (!film) return res.status(404).json({ message: "No film found. "});
    return res.status(200).json({film});
  });
}

function filmsDelete(req, res) {
  Film.findByIdAndRemove(req.params.id, err => {
    if (err) return res.status(500).json({ messsage: "Something went wrong." });
    return res.status(204).json();
  });
}
