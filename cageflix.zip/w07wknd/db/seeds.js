const mongoose = require("mongoose");
const config   = require("../config/config");
const Film     = require("../models/film");

mongoose.connect(config.db);

const films = [
  {
    title:       "The Wicker Man",
    image:       "https://s.graphiq.com/sites/default/files/7522/media/images/The_Wicker_Man_6744004.jpg",
    description: "A reclusive lawman (Nicolas Cage) travels to a secluded island to search for a girl who has gone missing. Once there, he discovers sinister forces at work among the island's secretive residents, including strange sexual rituals, a harvest festival and possible human sacrifice.",
    anyGood:     false,
    imdbRating:  3.7,
    year:        2006
  },
  {
    title:       "Con Air",
    image:       "https://fanart.tv/fanart/movies/1701/movieposter/con-air-5343d8694c270.jpg",
    description: "Just-paroled army ranger Cameron Poe (Nicolas Cage) is headed back to his wife, but must fly home aboard a prison transport flight with some of the worst criminals living. Genius serial killer Cyrus 'The Virus' Grissom (John Malkovich) unleashes a violent escape plot in mid-flight. Secretly working with U.S. Marshall Vince Larkin, Poe tries to foil Grissom's plan.",
    anyGood:     false,
    imdbRating:  6.8,
    year:        1997
  },
  {
    title:       "Face Off",
    image:       "https://i.jeded.com/i/faceoff-face-off.457.jpg",
    description: "Obsessed with bringing terrorist Castor Troy (Nicolas Cage) to justice, FBI agent Sean Archer tracks down Troy, who has boarded a plane in Los Angeles. After the plane crashes and Troy is severely injured, Archer undergoes surgery to remove his face and replace it with Troy's. As Archer tries to use his disguise to elicit information about a bomb from Troy's brother, Troy awakes from a coma and forces the doctor who performed the surgery to give him Archer's face.",
    anyGood:     true,
    imdbRating:  7.3,
    year:        1997
  },
  {
    title:       "Adaptation",
    image:       "http://www.impawards.com/2002/posters/adaptation.jpg",
    description: "Nicolas Cage is Charlie Kaufman, a confused L.A. screenwriter overwhelmed by feelings of inadequacy, sexual frustration, self-loathing, and by the screenwriting ambitions of his freeloading twin brother Donald (Nicolas Cage). While struggling to adapt 'The Orchid Thief' by Susan Orlean, Kaufman's life spins from pathetic to bizarre. The lives of Kaufman, Orlean's book, become strangely intertwined as each one's search for passion collides with the others'.",
    anyGood:     true,
    imdbRating:  7.7,
    year:        2003
  },
];

Film.collection.drop();

films.forEach(film => Film.create(film, (err, film) => {
  if (err) return console.log(err);
  return console.log(`${film.title} was created`);
}));
