module.exports = {
  db: "mongodb://localhost/nicolas-cage",
  secret: process.env.SECRET || "gosh this is so secret... shhh..."
};
