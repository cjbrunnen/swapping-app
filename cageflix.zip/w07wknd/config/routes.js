const router           = require("express").Router();
const films            = require("../controllers/films");
const authentications  = require("../controllers/authentications");
const users            = require("../controllers/users");

router.route("/films")
  .get(films.index)
  .post(films.create);
router.route("/films/:id")
  .get(films.show)
  .put(films.update)
  .patch(films.update)
  .delete(films.delete);

  router.route("/register")
    .post(authentications.register);
  router.route("/login")
    .post(authentications.login);

  router.route('/users')
    .get(users.index);
  router.route('/users/:id')
    .get(users.show)
    .put(users.update)
    .delete(users.delete);

module.exports = router;
