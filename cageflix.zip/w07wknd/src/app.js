angular
  .module("cageFlixApp", [
    "ui.router",
    "ngResource"
  ]);
