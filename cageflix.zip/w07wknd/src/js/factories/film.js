angular
  .module("cageFlixApp")
  .factory("Film", Film);

Film.$inject = ["$resource", "API"];
function Film($resource, API) {
  return $resource(`${API}/films/:id`, { id: "@_id" }, {
    'query':  { method: "GET", isArray: false },
    'update': { method: "PUT" }
  });
}
