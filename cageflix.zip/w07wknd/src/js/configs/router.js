angular
  .module("cageFlixApp")
  .config(Router);

Router.$inject = ["$stateProvider", "$urlRouterProvider", "$locationProvider"];
function Router($stateProvider, $urlRouterProvider, $locationProvider){
  $locationProvider.html5Mode(true);

  $stateProvider
  .state("home", {
    url: "/",
    templateUrl: "/js/views/home.html",
    controller: "HomeCtrl as home"
  })
  .state("filmsIndex", {
    url: "/films",
    templateUrl: "/js/views/films/index.html",
    controller: "FilmsIndexCtrl as cage"
  })
  .state("filmsNew", {
    url: "/films/new",
    templateUrl: "/js/views/films/new.html",
    controller: "FilmsNewCtrl as cage"
  })
  .state("filmsShow", {
    url: "/films/:id",
    templateUrl: "/js/views/films/show.html",
    controller: "FilmsShowCtrl as cage"
  })
  .state("filmsEdit", {
    url: "/films/:id/edit",
    templateUrl: "/js/views/films/edit.html",
    controller: "FilmsEditCtrl as cage"
  })
  .state("register", {
    url: "/register",
    templateUrl: "/js/views/register.html",
    controller: "registerCtrl as register",
  })
  .state("login", {
    url: "/login",
    templateUrl: "/js/views/login.html",
    controller: "loginCtrl as login",
  })
  .state("usersIndex", {
    url: "/users",
    templateUrl:  "/js/views/users/index.html",
    controller:   "usersIndexCtrl as usersIndex",
  });

  $urlRouterProvider.otherwise("/");

}
