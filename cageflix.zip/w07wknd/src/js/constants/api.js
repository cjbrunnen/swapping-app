angular
  .module("cageFlixApp")
  .constant("API", `${window.location.origin}/api`);
