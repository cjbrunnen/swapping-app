angular
  .module("cageFlixApp", [
    "ui.router",
    "ngResource",
    "angular-jwt"
  ]);
