angular
  .module("cageFlixApp")
  .controller("HomeCtrl", HomeCtrl);

HomeCtrl.$inject = [];
function HomeCtrl(){
  const vm = this;
  this.blurb = "A website that celebrates the filmic oeuvre of";
  this.cage = "Nicolas Cage";
  this.image = "http://screencrush.com/442/files/2015/12/nicholas-cage-con-air.jpg";
}
