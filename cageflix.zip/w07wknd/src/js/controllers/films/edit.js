angular
  .module("cageFlixApp")
  .controller("FilmsEditCtrl", FilmsEditCtrl);

FilmsEditCtrl.$inject = ["Film", "$stateParams", "$state"];
function FilmsEditCtrl(Film, $stateParams, $state){
  const vm = this;

  Film.get($stateParams, data => {
    vm.film = data.film;
  });

  vm.submit = () => {
    Film
      .update($stateParams, { film: vm.film })
      .$promise
      .then(data => {
        $state.go("filmsShow", $stateParams);
      });
  };
}
