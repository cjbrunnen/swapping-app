angular
  .module("cageFlixApp")
  .controller("FilmsIndexCtrl", FilmsIndexCtrl);

FilmsIndexCtrl.$inject = ["Film"];
function FilmsIndexCtrl(Film){
  const vm = this;
  Film
    .query()
    .$promise
    .then(data => {
      vm.films = data.films;
    });
}
