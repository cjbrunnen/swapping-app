angular
  .module("cageFlixApp")
  .controller("FilmsShowCtrl", FilmsShowCtrl);

FilmsShowCtrl.$inject = ["Film", "$stateParams", "$state"];
function FilmsShowCtrl(Film, $stateParams, $state){
  const vm = this;

  Film.get($stateParams, data => {
    vm.film = data.film;
  });

  vm.filmDelete = () => {
    Film
      .delete($stateParams)
      .$promise
      .then(data => {
        $state.go("filmsIndex");
      });
  };
}
