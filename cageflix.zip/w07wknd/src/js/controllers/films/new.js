angular
  .module("cageFlixApp")
  .controller("FilmsNewCtrl", FilmsNewCtrl);

FilmsNewCtrl.$inject = ["Film", "$state"];
function FilmsNewCtrl(Film, $state){
  const vm  = this;
  vm.submit = () => {
    Film
      .save({ film: vm.film })
      .$promise
      .then(data => {
        $state.go("filmsIndex");
      });
  };
}
